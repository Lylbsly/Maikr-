(function() {
    var AccountController, LoginController, MainController, HostController, libs;
    MainController = function($scope, $rootScope, $location, $timeout, validate, storage, track, LOGIN_EVENT_NAME, SERVER_CERT_INTERVAL) {
        $rootScope.state = "host";
        $rootScope.step = "login";
        $rootScope.name = '';
        if ($rootScope.isVirgin) {
            track.event('virgin-login-0528', 'visit')
        }
        $scope.source = function() {
            return $location.search().source
        };
        $rootScope.$watch("step", function(step) {
            return $location.path("/" + step)
        });
        $rootScope.validateHostFormat = function(host) {
            return validate.url(host);
        }
        $rootScope.betweenCertInterval = function() {
            var now;
            return SERVER_CERT_INTERVAL[0] < (now = new Date) && now < SERVER_CERT_INTERVAL[1]
        };
        return $rootScope.switchState = function(state) {
            return $rootScope.state = state
        }
    };
    HostController = function($scope, $rootScope, $http, $timeout, $log, validate, track, SERVER ,userManager, pageManager, storage) {
        var doRegister;
        $scope.focuses = {
            host: true
        };
        $rootScope.$watch('state', function(newVal) {
            if (newVal === 'host') {
                return $scope.focuses.host = true
            }
        });
        $scope.checkHost = function(host) {

            return validate.url(host);
            //return validate.phone(name) || validate.email(name)
        };
        $scope.checkHostNameExistence = function() {
            alert();
            var field = $scope.host;
            //alert(field);
            //alert("checkHostNameExistence");
            //field.$stateVisible = true;    

            
            var host = $rootScope.host;

            var valid = validate.url(host);

            
            if(!valid){
                $rootScope.host = '';
                $scope.focuses = {
                    host: true
                };
                return false;
            }

            var parser = document.createElement('a');
            parser.href = host;

            SERVER.scheme = parser.protocol + "//";

            SERVER.host = parser.host;
            //alert(SERVER.host);
            SERVER.port = parser.port;



            var pathname = parser.pathname.toString();

            //TODO:
            /*
            if(pathname.endsWith('/')){
                pathname = pathname.substr(0, pathname.length - 1);
            }
            */
            SERVER.contextPath = pathname;       
            $rootScope.switchState('account');

        };  
    };




    AccountController = function($scope, $rootScope, $http, $timeout, $log, validate, track, SERVER, userManager, pageManager, storage) {
        var doRegister;
        $scope.focuses = {
            name: true
        };
        $rootScope.$watch('state', function(newVal) {
            if (newVal === 'account') {
                return $scope.focuses.name = true
            }
        });
        $scope.checkName = function(name) {
            return validate.phone(name) || validate.email(name)
        };
        $scope.checkNameExistence = function() {
            var field, name;
            field = $scope.account.name;
            field.$stateVisible = true;
            name = $rootScope.name;


            if ($scope.account.$valid) {
                $scope.disableInput = true;
                return $http({
                    method: 'GET',
                    url: "https://" + SERVER.host  + SERVER.contextPath + "/user",
                    params: {
                        name: name
                    }
                }).success(function(resp) {
                    $scope.disableInput = false;
                    if (resp.exists) {
                        $rootScope.switchState('login');
                        if ($rootScope.isVirgin) {
                            return track.event('virgin-login-0528', 'login-start')
                        }
                    } else {
                        return doRegister()
                    }
                }).error(function() {
                    $scope.disableInput = false;
  
                })
            }
        };
        return doRegister = function() {
            $scope.disableInput = true;
            return $http({
                method: 'POST',
                url: "https://" + SERVER.host + SERVER.contextPath + "/user/register_with_name",
                params: {
                    name: $rootScope.name
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(resp) {
                if (resp.error) {
                    alert(resp.message);
                    return $scope.disableInput = false
                } else {
                    track.pv("/chrome-extension/register/success");
                    if ($rootScope.isVirgin) {
                        track.event('virgin-login-0528', 'register-success')
                    }
                    userManager.load(resp);
                    userManager.checkin().then(function() {
                        return pageManager.gotoOptions("#domains?source=afterRegister")
                    });
                    return storage.set('afterRegister', true)
                }
            }).error(function() {
                $scope.disableInput = false;
            })
        }
    };
    LoginController = function($scope, $rootScope, $location, $http, $log, $timeout, userManager, pageManager, validate, track, SERVER, storage, server) {
        $scope.name
        $scope.name = $location.search().name || storage.get("lastLoginName", "");

        $scope.password = "";
        $scope.resetPasswordUrl = "https://" + SERVER + "/user/password/";
        $scope.focuses = {
                host: true,
                name: false,
                password: false
        };
        $scope.submitting = false;
        $scope.checkingName = false;
        $scope.checkingHost = false;
        $scope.clearFormValidity = function() {
            return $scope.login.name.$setValidity("notExisted", true), 
                $scope.login.name.$setValidity("server", true), 
                $scope.login.password.$setValidity("mismatch", true)
        };
        $scope.checkHostExistence = function(login) {
            var host = $scope.host;
            //console.log(login.host);
            //console.log(host);
            var valid = $rootScope.validateHostFormat(host);
            //console.log(valid);
            if(!valid){
                $scope.login.$valid = false;
                login.host.$setValidity("format", false);
    
                //$scope.host = '';
                /*
                $scope.focuses = {
                    host: true
                };
                */
                return false;
            }

            return true;
        };
        $scope.checkNameExistence = function() {
            $scope.login.name.$setValidity("format", false);
        };
        //alert();
        return $scope.doLogin = function() {
            var field;
            //alert("doLogin");
            field = $scope.login.password;
            field.$stateVisible = true;
            if (!$scope.login.$valid) {
                return false
            }
            $scope.disableInput = true;
            $http({
                method: 'POST',
                //url: "/user/login",
                url: "https://" + SERVER.host + SERVER.contextPath +  "/user/",
                params: {
                    name: $rootScope.name,
                    password: $scope.password
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function(resp) {
                if (resp.error) {
                    if (resp.error === 'PASSWORD') {
                        field.$setValidity('errorPassword', false)
                    } else {
                        alert(resp.message)
                    }
                    return $scope.disableInput = false
                } else {
                    track.pv("/chrome-extension/login/success");
                    if ($rootScope.isVirgin) {
                        track.event('virgin-login-0528', 'login-success')
                    }
                    


                    /*
                    server.createClient(resp, function(){
                        alert("createClient funish:");
                        return pageManager.gotoOptions()
                    });
                    */

                    userManager.load(resp);

                    //server.createClient(resp).then(function() {



                        /*
                        userManager.load(resp);
                        userManager.checkin().then(function() {
                            return pageManager.gotoOptions()
                        });
*/
                        //return pageManager.gotoOptions()
                    //});


                    server.createClient(resp).then(function() {
                        //alert("createClient(resp).then");
                        userManager.checkin().then(function() {
                            return pageManager.gotoOptions()
                        });
                    });
                    /*
                    server.createClient(resp);
                    server.on('onopen', function(){
                        alert("onopen");
                        userManager.checkin().then(function() {
                            return pageManager.gotoOptions()
                        });
                    });
                    */
                    //userManager.checkin().then(function() {
                        //return pageManager.gotoOptions()
                    //});
                    return $log.info('login ok!')
                }
            }).error(function() {
                $scope.disableInput = false;
            });
            return false
        }
    };
    libs = ['underscore', 'angular', 'angular_ui_keypress', 'lang', 'angular_ui_router', 'ngRoute', 'angular_translate', 'ngSanitize', 'angular_ui_utils', 'angular_strap_tpl','services/server', 'services/domainUtils', 'services/validate', 'services/pageManager', 'services/storage', 'services/userManager', 'services/track', 'directives/focusBind', 'directives/fixAutoFill', 'directives/formState'];
    require(['config'], function() {
        return requireWithRetry(libs, function(_, angular, ui_keypress, lang) {
            var login;
            login = angular.module('login', ['pascalprecht.translate', 'ui.keypress', 'ngRoute','mgcrea.ngStrap', 'app', 'ui.utils', 'ngSanitize']);

            login.controller({
                MainController: MainController,
                AccountController: AccountController,
                "LoginController": LoginController,
                "HostController" : HostController
            });

            
            login.config(function($routeProvider, $translateProvider) {
                
                $routeProvider.when("/login", {
                    templateUrl: "/partials/login/login.html",
                    controller: "LoginController"
                }).otherwise({
                    redirectTo: "/login"
                });
                return lang.config($translateProvider);
            });
            login.run(function(track) {
                return track.pv('/chrome-extension/login')
            });
            return angular.element(document).ready(function() {
                return angular.bootstrap(document, ['login'])
            })
        })
    })
}).call(this);