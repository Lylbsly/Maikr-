(function() {
	var libs, LoginPageControllerOps;
	libs = ["angular", "app",  "services/storage", "services/validate", "login/module"], 
		LoginPageControllerOps = function(angular) {
		var LoginPageController = function($rootScope, $scope, $location, $translate, storage, validate, VER, LOGIN_EVENT_NAME, SERVER_CERT_INTERVAL, LOCALES) {
			$scope.ver = VER;
			var currentLocale = storage.get("currentLocale", LOCALES.preferredLocale);
			$translate.use(currentLocale);

			$scope.zh_only = ($translate.use() == "zh") ? true : false;
			return $rootScope.step = "login", 
			$rootScope.isVirgin = !storage.get("lastLoginName"), 
			$rootScope.validateNameFormat = function(e) {
				var r;
				if(!e || e === ''){
					return false;
				}
				return r = validate.phone(e) || validate.email(e)
			}, 
			$rootScope.validateEmailFormat = function(e) {
				var r;
				if(!e || e === ''){
					return false;
				}
				return r = validate.email(e)
			}, 
			$rootScope.betweenCertInterval = function() {
				var e;
				return SERVER_CERT_INTERVAL[0] < (e = new Date) && e < SERVER_CERT_INTERVAL[1]
			}, 
			$scope.search = function() {
				return $location.search()
			},
			
			$rootScope.isVirgin && ($rootScope.step = "trial"), 
			$rootScope.$watch("step", function(e) {
				return $location.path("/" + e)
			})

			//, tele.run("track.pv", "/chrome-extension/login")
		};
		return angular.module("login").controller("LoginPageController", ['$rootScope', '$scope', '$location', '$translate', 'storage', 'validate', 'VER', 'LOGIN_EVENT_NAME', 'SERVER_CERT_INTERVAL', 'LOCALES', LoginPageController]);
	}, 
	define(libs, LoginPageControllerOps)
}).call(this);