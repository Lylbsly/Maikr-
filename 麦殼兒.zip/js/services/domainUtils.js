(function() {
	var domainUtils, __indexOf = [].indexOf ||
	function(item) {
		for (var i = 0, l = this.length; i < l; i++) {
			if (i in this && this[i] === item) return i
		}
		return -1
	};
	domainUtils = function(validate) {
		var a, filterIllegalChar;
		this.dnsDomainIs = function(domain, base) {
			var rIndex, rightRemains;
			if(base.contains(".")){
				
				if (domain === base) {
					return true
				} else {
					rIndex = domain.lastIndexOf(base);
					if (rIndex <= 0) {
						return false
					} else {
						rightRemains = domain.length - (rIndex + base.length);
						if (domain[rIndex - 1] === '.' && rightRemains <= 0) {
							return true
						} else {
							return false
						}
					}
				}
			} else {
				//console.log("dnsDomainIs:" + base + " domain:" + domain);
				if(this.isTopDomain(base)){
					//console.log("dnsDomainIs2:" + base + " domain:" + domain);
					rIndex = domain.lastIndexOf(base);
					//console.log("dnsDomainIs3:" + rIndex);
					if (rIndex <= 0) {
						return false
					} else {
						rightRemains = domain.length - (rIndex + base.length);
						if (domain[rIndex - 1] === '.' && rightRemains <= 0) {
							return true
						} else {
							return false
						}
					}
				} else {
					//console.log("dnsDomainIs4:" + domain + " base:" + base);
					if(!domain.contains(".")) return false;
					var parts = domain.split('.');
					var i, _i;
					for (i = _i = parts.length - 1; _i >= 0; i = _i += -1) {
						//console.log("dnsDomainIs5:" + parts[i]);
						if(parts[i] === base) return true;
					}
					return false;
				}
			}
		};
		a = document.createElement('a');
		this.parseUri = function(url) {
			var query, queryStr;
			if (!url) {
				return {}
			}
			a.href = url;
			queryStr = a.search;
			query = {};
			if (queryStr) {
				queryStr = queryStr.slice(1);
				queryStr.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function($0, $1, $2) {
					if ($0) {
						return query[$1] = $2
					}
				})
			}
			return {
				protocol: a.protocol.slice(0, -1),
				user: a.username,
				password: a.password,
				host: a.hostname,
				port: a.port,
				path: a.pathname,
				hash: a.hash,
				query: query
			}
		};
		filterIllegalChar = function(domain) {
			return domain.replace(/[^0-9a-zA-Z\-\.]/ig, "")
		};

		this.trimDomain = function(domain) {
			domain = filterIllegalChar(domain);
			if (!domain) {
				return ''
			}
			return domain.trim()
		};


		this.topDomains = ['ac', 'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao', 'aq', 'ar', 'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb', 'bd', 'be', 'bf', 'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo', 'br', 'bs', 'bt', 'bu', 'bv', 'bw', 'by', 'bz', 'ca', 'cc', 'cd', 'cf', 'cg', 'ch', 'ci', 'ck', 'cl', 'cm', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cx', 'cy', 'cz', 'dd', 'de', 'dj', 'dk', 'dm', 'do', 'dz', 'ec', 'ee', 'eg', 'eh', 'er', 'es', 'et', 'eu', 'fi', 'fj', 'fk', 'fm', 'fo', 'fr', 'ga', 'gb', 'gd', 'ge', 'gf', 'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp', 'gq', 'gr', 'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'hr', 'ht', 'hu', 'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'ir', 'is', 'it', 'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km', 'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk', 'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me', 'mg', 'mh', 'mk', 'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr', 'ms', 'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc', 'ne', 'nf', 'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz', 'om', 'pa', 'pe', 'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn', 'pr', 'ps', 'pt', 'pw', 'py', 'qa', 're', 'ro', 'ru', 'rw', 'sa', 'sb', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj', 'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su', 'sv', 'sy', 'sz', 'tc', 'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tm', 'tn', 'to', 'tp', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug', 'uk', 'um', 'us', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn', 'vu', 'wf', 'ws', 'ye', 'yt', 'yu', 'za', 'zm', 'zr', 'zw', 
							'com', 'net', 'org', 'mil', 'gov', 'edu', 'nato', 'info', 
							'accountants', 'adult', 'app', 'art', 'asia', 'associates',
							'baby', 'band', 'bargains', 'best', 'bid', 'bingo', 'bio', 'biz', 'blog', 'build', 'business', 'buzz',
							'cab', 'cafe', 'cam', 'camera', 'camp', 'care', 'casino', 'center', 'chat', 'church', 'city', 'club', 'cloud', 'codes', 'coffee', 'cool', 'college', 'company', 'community', 'computer', 'consulting',
							'deals', 'design', 'dev', 'digital', 'directory', 'doctor', 'domains', 'download',
							'eco', 'email', 'enterprises', 'events', 'express', 'exchange', 'expert',
							'film', 'fit', 'foundation', 'fun',
							'game', 'games', 'global', 'group', 'guru', 
							'help', 'host', 'holdings',
							'jobs', 
							'life', 'limited', 'link', 'live', 'llc', 'love', 'ltd',
							'icu', 'id', 'inc', 'ink', 'int', 'international',
							'kim',
							'management', 'media', 'moe', 'mobi', 'money', 'movie', 'mom', 'monster', 'museum',
							'name', 'network', 'news',
							'observer', 'onl', 'online', 
							'page', 'partners', 'party', 'photo', 'photography', 'photos', 'pics', 'pictures', 'plus', 'porn', 'press', 'pro', 'productions', 'protection', 'pub',
							'recipes', 'rest', 'rocks', 'run',
							'school', 'security', 'services', 'sex', 'sexy', 'shop', 'show', 'site', 'social', 'software', 'solar', 'solutions', 'soy', 'space', 'storage', 'store', 'stream', 'studio', 'surf', 'systems',
							'tax', 'team', 'technology', 'tech', 'tel', 'tips', 'today', 'top', 'tools', 'trade',
							'university',
							'vet', 'video', 'vip', 'vision',
							'webcam', 'wiki', 'wine', 'work', 'works', 'world', 'wtf',
							'xxx', 'xyz',
							'zone'];

		this.isTopDomain = function(domain) {
			if (__indexOf.call(this.topDomains, domain) >= 0){
				return true;
			}
			return false;
		};

		this.topDomain = (function(_this) {
			return function(domain) {
				var i, ltds, part, parts, trimedParts, _i;
				domain = filterIllegalChar(domain);
				if (!domain) {
					return domain
				}
				if (!validate.domain(domain)) {
					return domain
				}
				ltds = _this.topDomains;
				//ltds = ['ac', 'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao', 'aq', 'ar', 'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb', 'bd', 'be', 'bf', 'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo', 'br', 'bs', 'bt', 'bu', 'bv', 'bw', 'by', 'bz', 'ca', 'cc', 'cd', 'cf', 'cg', 'ch', 'ci', 'ck', 'cl', 'cm', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cx', 'cy', 'cz', 'dd', 'de', 'dj', 'dk', 'dm', 'do', 'dz', 'ec', 'ee', 'eg', 'eh', 'er', 'es', 'et', 'eu', 'fi', 'fj', 'fk', 'fm', 'fo', 'fr', 'ga', 'gb', 'gd', 'ge', 'gf', 'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp', 'gq', 'gr', 'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'hr', 'ht', 'hu', 'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'ir', 'is', 'it', 'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km', 'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk', 'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me', 'mg', 'mh', 'mk', 'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr', 'ms', 'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc', 'ne', 'nf', 'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz', 'om', 'pa', 'pe', 'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn', 'pr', 'ps', 'pt', 'pw', 'py', 'qa', 're', 'ro', 'ru', 'rw', 'sa', 'sb', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj', 'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su', 'sv', 'sy', 'sz', 'tc', 'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tm', 'tn', 'to', 'tp', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug', 'uk', 'um', 'us', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn', 'vu', 'wf', 'ws', 'ye', 'yt', 'yu', 'za', 'zm', 'zr', 'zw', 'com', 'net', 'org', 'mil', 'gov', 'edu', 'nato', 'info', 'adult', 'bid', 'asia', 'app', 'best', 'biz', 'blog', 'club', 'cloud', 'design', 'dev', 'guru', 'jobs', 'life', 'link', 'love', 'int', 'io', 'name', 'mobi', 'movie', 'museum', 'online', 'porn', 'pro', 'shop', 'tech', 'tel', 'top', 'xxx', 'xyz'];
				parts = domain.split('.');
				trimedParts = [];
				for (i = _i = parts.length - 1; _i >= 0; i = _i += -1) {
					part = parts[i];
					if (__indexOf.call(ltds, part) >= 0 || i === parts.length - 1) {
						trimedParts.unshift(part)
					} else {
						trimedParts.unshift(part);
						break
					}
				}
				return trimedParts.join('.')
			}
		})(this);
		return this
	};
	define(['../app', './validate'], function(app) {
		return app.service('domainUtils', domainUtils)
	})
}).call(this);